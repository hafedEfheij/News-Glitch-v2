import '@/ai/flows/summarize-article.ts';
import '@/ai/flows/detect-fake-news.ts';
import '@/ai/flows/verify-claim.ts'; // Add import for the new flow
